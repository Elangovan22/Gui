drop table ASSETMANAGEMENT_REQUEST cascade ;
