drop table ASSETMANAGEMENT_NEW__ASSET cascade ;
