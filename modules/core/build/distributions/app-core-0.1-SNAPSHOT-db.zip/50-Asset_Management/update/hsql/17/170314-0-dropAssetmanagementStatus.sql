drop table ASSETMANAGEMENT_STATUS cascade ;
