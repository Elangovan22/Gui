drop table ASSETMANAGEMENT_ASSET cascade ;
