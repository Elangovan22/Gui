drop table ASSETMANAGEMENT_SUPPLIER cascade ;
